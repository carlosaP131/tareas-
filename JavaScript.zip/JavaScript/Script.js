function convertir() {
    var kilometros = parseFloat(document.getElementById('kilometros').value);
    var millas = kilometros * 0.6213712;
    document.getElementById('resultado').innerHTML = kilometros + ' kilómetros son ' + millas + ' millas.';
  }