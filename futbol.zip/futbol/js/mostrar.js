$(document).ready(function() {
	$('#menu').on('click',function(){
		$('#slide').toggleClass('mostrar');
	});
});
